from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database configuration (replace with your actual credentials)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:admin123@localhost/student_management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    course = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f"Student('{self.id}', '{self.name}', {self.age}, '{self.course}')"


@app.route('/')
def home():
    students = Student.query.all()  # Fetch all students from the database
    return render_template('Dynamic.html', students=students)


@app.route('/add', methods=['POST'])
def add():
    form_name = request.form['name']
    form_age = int(request.form['age'])  # Convert age to integer
    form_course = request.form['course']

    new_student = Student(name=form_name, age=form_age, course=form_course)
    db.session.add(new_student)
    db.session.commit()

    return redirect(url_for('home'))


@app.route('/edit/<int:id>', methods=['GET', 'POST'])  
def edit_student(id):
    student = Student.query.get_or_404(id) 
    if request.method == 'GET':  
        return render_template('edit.html', student=student)  
    elif request.method == 'POST':  
        student.name = request.form['name']  
        student.age = int(request.form['age'])  
        student.course = request.form['course']
        db.session.commit()  
        return redirect(url_for('home'))  
    

@app.route('/delete/<int:id>', methods=['POST'])  
def delete_student(id):
    student = Student.query.get_or_404(id) 
    db.session.delete(student)
    db.session.commit()  
    return redirect(url_for('home'))  



if __name__ == '__main__':
    app.run(debug=True)
